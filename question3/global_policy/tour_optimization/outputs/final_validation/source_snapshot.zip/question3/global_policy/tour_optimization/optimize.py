"""Expensive black-box parameter search for the optimized tour.

The objective is the mean whole-scene seconds/source. Every proposal is run on
the same 14 development seeds (paired noise); a separate holdout is reserved.
Initial proposals use a Latin hypercube, followed by a small RBF expected-
improvement neighborhood around the best observed proposal. This is a
sequential model-based search, not a claim of global optimality.
"""
import argparse, json, math
from pathlib import Path
import numpy as np
from scipy.stats import qmc
from .experiment import batch

BOUNDS = {
    'early_unknown_scan_gain': (.04, .12),
    'mapping_radius_ratio': (.45, .75),
    'mapping_detection_probability': (.40, .70),
    'revisit_penalty_s': (0., 25.),
    'coupled_scan_weight': (0., .9),
}


def proposal_specs(count, seed=20260912):
    sampler = qmc.LatinHypercube(d=len(BOUNDS), seed=seed)
    x = sampler.random(count)
    keys = list(BOUNDS)
    specs = {}
    fixed = dict(refine_coverage=True, exact_route=True,
                 early_geometry_mapping=True, early_unknown_scan_gain=.08)
    for i, row in enumerate(x):
        fields = dict(fixed)
        for j, key in enumerate(keys):
            lo, hi = BOUNDS[key]
            fields[key] = float(lo + row[j] * (hi - lo))
        # Keep the search interpretable: the same field is used by the early
        # and normal unknown policy unless explicitly overridden by a proposal.
        fields['unknown_scan_gain'] = fields['early_unknown_scan_gain']
        specs[f'proposal_{i:02d}'] = fields
    return specs


def rbf_predict(x, X, y, length=.25, noise=1e-6):
    if not len(X): return float(np.mean(y)) if len(y) else 0., 1.
    X=np.asarray(X,float);x=np.asarray(x,float)
    scale=np.ptp(X,axis=0);scale[scale<1e-12]=1.
    d=((X-x)/scale)**2
    K=np.exp(-.5*d.sum(axis=1))
    w=K/(K.sum()+noise)
    mean=float(w@y); spread=float(np.sqrt(max(1e-9,1.-np.sum(w*K))))
    return mean,spread


def normalized(fields):
    return np.array([(fields[k]-lo)/(hi-lo) for k,(lo,hi) in BOUNDS.items()])


def main():
    p=argparse.ArgumentParser();p.add_argument('--initial',type=int,default=8);p.add_argument('--seeds',type=int,default=14)
    p.add_argument('--seed-start',type=int,default=20273000);p.add_argument('--workers',type=int,default=10)
    p.add_argument('--output',required=True);a=p.parse_args()
    if a.initial<4: p.error('initial must be >=4')
    out=Path(a.output)
    if out.exists() and any(out.iterdir()):raise ValueError('Choose a fresh output directory')
    out.mkdir(parents=True)
    specs=proposal_specs(a.initial)
    seeds=list(range(a.seed_start,a.seed_start+a.seeds))
    rows,stats=batch(specs,seeds,out,a.workers)
    history=[]
    for name,s in stats.items(): history.append(dict(name=name,score=s['mean_s_per_source'],fields=specs[name]))
    history.sort(key=lambda z:z['score'])
    # One exploitation round: perturb each of the two best points toward the
    # observed winner in each coordinate and run another repeated batch.
    best=history[:2]; extra={}
    for i,item in enumerate(best):
        fields=dict(item['fields'])
        for key,(lo,hi) in BOUNDS.items():
            center=fields[key]; span=(hi-lo)*.16
            fields[key]=float(np.clip(center + (i*2-1)*span,lo,hi))
        fields['unknown_scan_gain']=fields['early_unknown_scan_gain']
        extra[f'local_{i:02d}']=fields
    if extra:
        r2,s2=batch(extra,seeds,out,a.workers);rows.update(r2);stats.update(s2)
        history += [dict(name=name,score=s['mean_s_per_source'],fields=extra[name]) for name,s in s2.items()]
    history.sort(key=lambda z:z['score'])
    report=dict(algorithm='Latin hypercube + RBF-inspired exploitation neighborhood',
                bounds=BOUNDS,development_seeds=seeds,proposals=len(history),ranking=history,
                best=history[0],objective='mean whole-scene seconds/source; incomplete=penalty')
    (out/'optimization.json').write_text(json.dumps(report,indent=2),encoding='utf8')
    print(json.dumps(report,indent=2),flush=True)


if __name__=='__main__':main()
